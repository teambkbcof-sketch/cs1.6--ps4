python %*
