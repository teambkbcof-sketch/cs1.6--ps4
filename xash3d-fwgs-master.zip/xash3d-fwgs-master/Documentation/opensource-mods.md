Source code of this mods is available for modders and porters in public access.

# Original Work
## Absolute Zero
Official gitlab repository - https://gitlab.com/Cobalt-57/half-life-absolute-zero/

## Adrenaline Gamer
Official github repository by Martin \"Bullet\" Webrant - https://github.com/martinwebrant/agmod

## Arrangement
Mirrored on github - https://github.com/JoelTroch/am_src_30jan2011

## Arrangemode: Rebirth
Mirrored on github - https://github.com/JoelTroch/am_src_rebirth

## Battle Grounds
Mirrored on github - https://github.com/nekonomicon/BattleGrounds

## Brain Bread
Official github repository - https://github.com/IronOak-Studios/BrainBread

## Bubblemod
Download page on official site(WM snapshot) - [http://www.bubblemod.org/dl_default.php](https://web.archive.org/web/20130717133158/http://www.bubblemod.org/dl_default.php)

Mirrored on github - https://github.com/HLSources/BubbleMod

## Chicken Fortress
Official github repository - https://github.com/CKFDevPowered/CKF3Alpha

## Cold Ice
Version 1.9 is available on ModDB - https://www.moddb.com/mods/cold-ice/downloads/cold-ice-sdk

Version 1.9 mirrored on github - https://github.com/solidi/hl-mods/tree/master/ci

## Cold Ice Ressurection
Mirrored on github - https://github.com/solidi/hl-mods/tree/master/cir

## Counter-Life
Available on ModDB - https://www.moddb.com/mods/counter-life/downloads/cl-version-1-source-code

## Crack-Life Anniversary Campaign
Available on ModDB - https://www.moddb.com/mods/crack-life/downloads/crack-life-anniversary-campaign-sdk

## Cthulhu
Uploaded to github by Oleg Cherkasky - https://github.com/gunrunners-paradise/Cthulhu-HLmod-SDK

## Deathmatch Classic
Available in Valve's Half-Life repository - https://github.com/ValveSoftware/halflife/tree/master/dmc

## Delta Particles
Available on ModDB - https://www.moddb.com/mods/half-life-delta/downloads/delta-particles-full-sources-maps-and-c-code

## Earth Special Forces
Alpha 2.0 - https://www.gamers-desire.de/details/2830

## ESHQ
Official github repository - https://github.com/adslbarxatov/xash3d-for-ESHQ

## Feline
Available on ModDB - https://www.moddb.com/mods/feline-10/downloads/feline-sdk

## Flat-Life
Available on GamerLab - http://gamer-lab.com/eng/code_mods_goldsrc/Half-Life_2D_(Flat-Life)

## Gang Wars
Mirrored on github - https://github.com/nekonomicon/gw1.45src

## Go-Mod
Versions 2.0 and 3.0, available in mod archives on ModDB - https://www.moddb.com/mods/go-mod/downloads

Version 3.0, mirrored on github - https://github.com/nekonomicon/Go-mod30

## Go-Mod: Reborn
Official github repository - https://github.com/LambdaLuke87/Go-Mod-Reborn-Lite-Build

## GT mod
Available on GamerLab - http://gamer-lab.com/eng/code_mods_goldsrc/GT_mod_(Polnie_ishodniki)

## Half-Force
Available on ModDB - https://www.moddb.com/mods/half-force/downloads/half-force-v20-sdk

## Half-Life: Advanced Deathmatch
Mirrored on github - https://github.com/solidi/hl-mods/tree/master/hla

## Half-Life: Decay
Mirrored on github(PC Port) - https://github.com/hoaxer/Half-Life-Decay

## Half-Life: Echoes
Available on ModDB - https://www.moddb.com/mods/half-life-echoes

## Half-Life: Expanded Arsenal
Available on ModDB - https://www.moddb.com/mods/half-life-expanded-arsenal

## Half-Life: Featureful
Branch **featureful** in halflife-featureful - https://github.com/FreeSlave/halflife-featureful

## Half-Life: Field Intensity
Branch **field_intensity_1.7** in halflife-featureful - https://github.com/FreeSlave/halflife-featureful/tree/field_intensity_1.7

## Half-Life: Gravgun mod
Branch **gravgun** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/gravgun

## Half-Life: Induction
Version 1.4: Branch **induction** in halflife-featureful - https://github.com/FreeSlave/halflife-featureful/tree/induction

## Half-Life: Insecure
Version 1.5 is available on ModDB - https://www.moddb.com/mods/half-life-insecure/downloads/half-life-insecure-map-tools-and-source-code-ver-15

## Half-Life: Invasion
Official github repository - https://github.com/jlecorre/hlinvasion

## Half-Life: Pong
Mirrored on github - https://github.com/solidi/hl-mods/tree/master/pong

## Half-Life: Quest Mode
Available on cs-mapping.com.ua - https://old.cs-mapping.com.ua/forum/showthread.php?t=38030

## Half-Life: Sum
Original Version: Branch **sum_orig** in halflife-featureful - https://github.com/FreeSlave/halflife-featureful/tree/sum_orig

Version 2022: Branch **sum_2022** in halflife-featureful - https://github.com/FreeSlave/halflife-featureful/tree/sum_2022

Current Version: Branch **sum** in halflife-featureful - https://github.com/FreeSlave/halflife-featureful/tree/sum

## Half-Life: Top-Down
Official gitlab repository - https://gitlab.com/Sockman/hltopdown

## Half-Life: Update
Official github repository - https://github.com/Fograin/hl-subsmod-ex

## Half-Life: Rally
Official gitlab repository - https://gitlab.com/hlrally/src

## Half-Life: Reprocessing
Official github repository - https://github.com/EgorYak/ReprocessingSourceCode

## Half-Life: RXT
Available on ModDB - https://www.moddb.com/mods/half-life-rxt/downloads/rxt-source-code-v57

## Half-Life: Weapon Edition
Available on ModDB - https://www.moddb.com/mods/half-life-weapon-edition/downloads/half-life-weapon-edition-1508-alpha-open-src

## Half-Life: Year of the Dragon
Available on ModDB - https://www.moddb.com/mods/year-of-the-dragon

## Half-Nuked
Available on ModDB - https://www.moddb.com/mods/half-nuked/downloads/half-nuked-src

## Half-Payne
Official github repository - https://github.com/suXinjke/HalfPayne

## Half-Quake
Official github repository - https://github.com/muddasheep/hqtrilogy

## Half-Rats: Parasomnia
Official github repository - https://github.com/HeathGames/half_rats_parasomnia_src

## Half-Screwed
Official github repository - https://github.com/desukuran/half-screwed

## Halo: GoldSource
Available on ModDB - https://www.moddb.com/mods/halo-goldsrc/downloads/halo-gold-source-summer-2025-release-v10-sdk

## Headcrab Frenzy
Version 1.3 on ModDB - https://www.moddb.com/mods/headcrab-frenzy/downloads/headcrab-frenzy-13-beta-source-code

## Heart of Evil
Mirrored on github - https://github.com/nekonomicon/HeartOfEvil

Mirrored on github (Includes maps and models source files) - https://github.com/malortie/heart-of-evil-source-files

## Ingram Chillin' Mod
Official SourceForge repository - https://sourceforge.net/projects/icm-hl/

## Intense Force
Branch **intense_force** in halflife-featureful - https://github.com/FreeSlave/halflife-featureful/tree/intense_force

## Master Sword
Official github repository of Master Sword Classic - https://github.com/BerntA/MasterSwordClassic

Official github repository of Master Sword Rebirth - https://github.com/MSRevive/MasterSwordRebirth

## MechMod
Official github repository - https://github.com/vermagav/mechmod

## Mortal Combat Forever
Available on GamerLab - http://gamer-lab.com/eng/code_mods_goldsrc/Mortal_Combat_Forever_(Polnie_ishodniki)

## Natural Selection
Official github repository - https://github.com/unknownworlds/NS

## Overturn
Available in mod archive on ModDB - https://www.moddb.com/mods/overturn

## Oz Deathmatch
Mirrored on github - https://github.com/nekonomicon/OZDM

## Paranoia
Available on ModDB - https://www.moddb.com/mods/paranoia/downloads/paranoia-toolkit

## Paranoia 2: The Savior
Prealpha, mirrored on github - https://github.com/a1batross/Paranoia2_ancient

Version 1.51, mirrored on github - https://github.com/a1batross/Paranoia2_original

## Public Enemy
Official github repository - https://github.com/IronOak-Studios/Public-Enemy

## Raven City
*Unfinished mod*

Was found on HLFX - http://hlfx.ru/forum/showthread.php?s=2c892dfc52f72be52a89c3f52a397cd0&threadid=1819&postid=44674#post44674

## Ricochet
Available in Valve's Half-Life repository - https://github.com/ValveSoftware/halflife/tree/master/ricochet

## Spirit of Half-Life
[Logic&Trick's](https://github.com/LogicAndTrick) mirror - https://files.logic-and-trick.com/#/Half-Life/Mods/Spirit%20of%20Half-Life

## The Last Bullet
Official github repository - https://github.com/GT-Project-Cat/The-Last-Bullet-Updated-Code

## The Wastes
Version 1.5: mirrored on code.idtech.space - https://code.idtech.space/vera/halflife-thewastes-sdk

## Threewave CTF
*Unfinished mod by Valve Software*

Available in Valve's Half-Life repository with Deathmatch Classic sources - https://github.com/ValveSoftware/halflife/tree/master/dmc

## Trinity Render
Available on ModDB - https://www.moddb.com/mods/half-life-episode-two/downloads/trinity-rendering-engine-v308f

## Tyrian: Ground Assault
Available on ModDB - https://www.moddb.com/mods/tyriangroundassault/downloads/tyrianga-v1-0-src

## Wasteland
Mirrored on code.idtech.space - https://code.idtech.space/vera/halflife-wasteland-sdk

## Wizard Wars
Download page on official site - http://www.thothie.com/ww/

## Wrong Door
Available on ModDB - https://www.moddb.com/mods/wrong-door/downloads/wrong-door-sdk

## XDM
*This mod is opensource but access to source code is always rebus*

How to get sources of version 3.0.4.3:

Download SFX-archive from ModDB - https://www.moddb.com/mods/xdm/downloads/xdm3043

Extract it.

Open client.dll in HEX-editor and patch header - change `Win!` to `Rar!`

Extract it using unrar - password `iamtheone` 

## XashXT
Mirrored on github - https://github.com/a1batross/XashXT_original

## Xen-Warrior
*Source code is a part of Spirit of Half-Life 1.0-1.2 under XENWARRIOR macro*

[Logic&Trick's](https://github.com/LogicAndTrick) mirror - https://files.logic-and-trick.com/#/Half-Life/Mods/Spirit%20of%20Half-Life

## Yet another PS2 Half-Life port
Official github repository - https://github.com/supadupaplex/ya-ps2hl-dll

## Zombie Panic!
Official github repository - https://github.com/Monochrome-Inc/ZombiePanic-HL

## Zombie-X
Available in mod archive on ModDB - https://www.moddb.com/mods/zombie-x-10-final/downloads/zombie-x-10-dle-beta6-last-version

## ZXC
Available on ModDB - https://www.moddb.com/mods/zxc-mod-133/downloads/zxc-mod-136-final

Mirrored on github - https://github.com/ZXCmod/ZXCmod

# Reimplementation
## Absolute Redemption
Branch **redempt** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/redempt

## Adrenaline Gamer
OpenAG by YaLTeR - https://github.com/YaLTeR/OpenAG

## Afraid of Monsters
malortie's recreation - https://github.com/HL1-Mods-Reimplementations-and-Ports/hl-aom

Branch **aom** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/aom

## Afraid of Monsters: Director's cut
Reverse-engineered code: branch **aomdc** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/aomdc

## Azure Sheep
malortie's recreation - https://github.com/HL1-Mods-Reimplementations-and-Ports/hl-asheep

Reverse-engineered code: branch **asheep** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/asheep

## Big Lolly
malortie's recreation - https://github.com/HL1-Mods-Reimplementations-and-Ports/hl-biglolly

Branch **biglolly** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/biglolly

## Black Ops
malortie's recreation - https://github.com/HL1-Mods-Reimplementations-and-Ports/hl-blackops

Branch **blackops** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/blackops

## Bloody Pizza: Vendetta
Branch **caseclosed** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/caseclosed

## Case Closed
Branch **caseclosed** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/caseclosed

## Cleaner's Adventures
Branch **CAd** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/CAd

## Counter Strike
Reverse-engineered code of client part by a1batross - https://github.com/Velaron/cs16-client

Reverse-engineered code of server part by nagist - https://github.com/nagist/cs16nd

Reverse-engineered code of server part by s1lentq - https://github.com/s1lentq/ReGameDLL_CS

## Counter Strike Online
CSO-like Xash3D-based mod, CSMoE - https://github.com/MoeMod/CSMoE

## Crack-Life
Reverse-engineered code: branch **cracklife** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/cracklife

## Crack-Life: Campaign Mode
Recreation by lostgamer aka nillerusr - https://github.com/LostGamerHL/crack_life

Reverse-engineered code: branch **clcampaign** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/clcampaign

## Escape from the Darkness
malortie's recreation - https://github.com/HL1-Mods-Reimplementations-and-Ports/hl-eftd

Reverse-engineered code: branch **eftd** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/eftd

## Half-Life: Black Guard
*This mod uses dlls from Cleaner's Adventures*

Branch **CAd** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/CAd

## Half-Life: Blue Shift
Unkle Mike's recreation - https://hlfx.ru/forum/showthread.php?s=&threadid=5253

Reverse-engineered code: branch **bshift** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/bshift

## Half-Life: Induction
Version 1.0-1.2: Branch **induction_1.2** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/induction_1.2

## Half-Life: Opposing Force
Recreation by lostgamer aka nillerusr - https://github.com/LostGamerHL/hlsdk-xash3d

Reverse-engineered code: clean branch **opfor** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/opfor

Spirit of Half Life: Opposing-Force Edition - https://github.com/Hammermaps-DEV/SOHL-V1.9-Opposing-Force-Edition

## Half-Life: Rebellion
Reverse-engineered code: branch **rebellion** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/rebellion

## Half-Life: Urbicide
Branch **hl_urbicide** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/hl_urbicide

## Half-Life: Visitors
malortie's recreation - https://github.com/HL1-Mods-Reimplementations-and-Ports/hl-visitors

Reverse-engineered code: branch **visitors** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/visitors

## Half-Secret
Branch **half-secret** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/half-secret

## Night at the Office
malortie's recreation - https://github.com/HL1-Mods-Reimplementations-and-Ports/hl-nato

Branch **noffice** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/noffice

## Poke 646
malortie's recreation - https://github.com/HL1-Mods-Reimplementations-and-Ports/hl-poke646

Reverse-engineered code: branch **poke646** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/poke646

## Poke 646: Vendetta
malortie's recreation - https://github.com/HL1-Mods-Reimplementations-and-Ports/hl-poke646-vendetta

Reverse-engineered code: branch **poke646_vendetta** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/poke646_vendetta

## Residual Life
Reverse-engineered code: branch **residual_point** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/residual_point

## Residual Point
Reverse-engineered code: branch **residual_point** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/residual_point

## Sewer Beta
Branch **sewer_beta** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/sewer_beta

## Team Fortress Classic
Reverse-engineered code by Velaron - https://github.com/Velaron/tf15-client

## The Gate
malortie's recreation - https://github.com/HL1-Mods-Reimplementations-and-Ports/hl-thegate

Reverse-engineered code: branch **thegate** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/thegate

## They Hunger
malortie's recreation - https://github.com/HL1-Mods-Reimplementations-and-Ports/hl-theyhunger

Reverse-engineered code: branch **theyhunger** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/theyhunger

They Hunger: Tactical - https://www.moddb.com/mods/they-hunger-tactical/downloads/tht-source-code-documentation

## Times of Troubles
malortie's recreation - https://github.com/HL1-Mods-Reimplementations-and-Ports/hl-tot

Branch **tot** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/tot

# Derived work
## Adrenaline Gamer
Branch **aghl** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/aghl

## Bubblemod
Branch **bubblemod** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/bubblemod

## Counter-Life
Branch **counter-life** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/counter-life

## Deathmatch Classic
Deathmatch Classic: Adrenaline Gamer Edition - https://github.com/martinwebrant/agmod/tree/master/src/dmc

Deathmatch Quaked - https://www.moddb.com/games/deathmatch-classic/downloads/dmq2

Branch **dmc** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/dmc

## Delta Particles
Branch **delta_particles** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/delta_particles

## Half-Life: Echoes
Branch **echoes** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/echoes

## Half-Life: Insecure
Branch **insecure** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/insecure

## Half-Life: Invasion
Port to HLSDK 2.4 by malortie - https://github.com/HL1-Mods-Reimplementations-and-Ports/hl-invasion

Port to Linux by fmoraw - https://github.com/fmoraw/hlinvasion

Branch **invasion** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/invasion

## Half-Life: Top-Down
Branch **hltopdown** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/hltopdown

## Half-Screwed
Branch **half-screwed** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/half-screwed

## Natural Selection
Port to Linux - https://github.com/fmoraw/NS

## Spirit of Half-Life
Version 1.2: branch **sohl1.2** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/sohl1.2

## Swiss Cheese Halloween 2002
Just more playable version by malortie - https://github.com/HL1-Mods-Reimplementations-and-Ports/hl-shall

Branch **halloween** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/halloween

## The Wastes
Version 1.5: Port to Linux - https://git.mentality.rip/a1batross/halflife-thewastes-sdk

## Threewave CTF
Branch **dmc** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/dmc

## Xen-Warrior
Branch **sohl1.2** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/sohl1.2

## Yet another PS2 Half-Life port
Branch **ps2hl** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/ps2hl

## Zombie-X
Branch **zombie-x** in hlsdk-portable - https://github.com/FWGS/hlsdk-portable/tree/zombie-x
